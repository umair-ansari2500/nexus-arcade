import 'package:flutter/material.dart';
import 'home/home.dart';
import 'dart:async';

void main() {
  runApp(const MaterialApp(
    home: Splash_Screen(),
    debugShowCheckedModeBanner: false,
    // change your app title name
    title: "Zontal App",
  ));
}

class Splash_Screen extends StatefulWidget {
  const Splash_Screen({super.key});

  @override
  State<Splash_Screen> createState() => _Splash_ScreenState();
}

class _Splash_ScreenState extends State<Splash_Screen> {
  @override
  void initState() {
    super.initState();
    Timer(
        const Duration(seconds: 5),
        () => Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const Home_page())));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white,
        child: Center(
            // change Your splash screen logo
            child: Image.network(
                "https://kaiseaurkya.in/static/img/logo/logo-dark.png")));
  }
}
